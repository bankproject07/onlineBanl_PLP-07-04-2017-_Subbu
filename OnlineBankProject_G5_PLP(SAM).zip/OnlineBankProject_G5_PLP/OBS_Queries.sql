
drop table Account_Master;
drop table customer;
drop table RequestTable;
drop sequence custId_seq;drop sequence accId_seq;



create sequence seq_fundtransfer_id start with 1000 increment by 1;

create sequence accId_seq start with 12001200 increment by 1;

create sequence custId_seq start with 1500200 increment by 1;

create sequence seq_service_num  start with 12000 increment by 1;

create sequence seq_transactionid  start with 130010 increment by 1;


insert into USER_TABLE values(123456,12001215,123,'hg','hgf',789,'U');

insert into account_master values(accid_seq.nextVal,1500201,'Saving',1500,'04-apr-2017');
insert into account_master values(accid_seq.nextVal,1500200,'Saving',2000,'04-apr-2017');


insert into Customer1 values(custId_seq.nextVal,'Subbu','subbu@gmamil.com',9856321470,'Kalyan','A123456');
insert into Customer1 values(custId_seq.nextVal,'Durva','durva@gmamil.com',9856321423,'Airoli','A123455');
create table RequestTable
(
customer_ID number(10) primary key,
AccountType varchar2(15),
AccountId number(10)
);


create table Customer1(
Customer_ID NUMBER(10) primary key,
customer_name VARCHAR2(50),
Email VARCHAR2(30),
Mobile_No NUMBER(10),
Address VARCHAR2(100),
Pancard VARCHAR2(15));



create table Account_Master
(Account_ID NUMBER(10) primary key,
Customer_ID number(10),
Account_Type VARCHAR2(25),
Account_Balance NUMBER(10,2),
Open_Date DATE,
FOREIGN KEY(Customer_ID) REFERENCES customer1(Customer_ID));




create table Transaction
(
Transaction_ID NUMBER primary key ,
Tran_description VARCHAR2(100),
DateofTransaction DATE ,
TransactionType VARCHAR2(1),
TranAmount NUMBER(15) ,
Account_ID NUMBER(10),
FOREIGN KEY(Account_ID) REFERENCES Account_Master(Account_ID)
);

insert into Transaction values (seq_transactionid.nextVal,'success','4-apr-2017','c',1000,12001203);

create table Payee_Table
(
Payee_Account_Id NUMBER primary key, 
Account_Id NUMBER,
Nick_name VARCHAR2(40),
foreign key(Account_ID) references Account_Master(Account_ID)
);


create table Service_Tracker(
Service_ID NUMBER(15) primary key, 
Service_Description VARCHAR2(100),
Account_ID NUMBER, 
Service_Raised_Date DATE ,
Service_status VARCHAR2(20),
foreign key(Account_ID) references Account_Master(Account_ID) 
);



create table User_Table
(
user_id VARCHAR2(20) primary key,
Account_ID NUMBER,
login_password VARCHAR2(15),
secret_question VARCHAR2(50),
secret_answer VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(10),foreign key(Account_ID) references Account_Master(Account_ID) 
);
select * from customer1;

select * from REQUESTTABLE;

select *  from ACCOUNT_MASTER;

select  * from TRANSACTION;
