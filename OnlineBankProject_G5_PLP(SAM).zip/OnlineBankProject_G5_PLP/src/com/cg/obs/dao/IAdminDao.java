package com.cg.obs.dao;

import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;

public interface IAdminDao 
{
	public Customer getCustomerbyId(int id) throws UserException;
	
	//Transaction details
	
	
		public List<Transactions> viewMonthlyReport(Date StartDate,Date EndDate) throws UserException;
		public List<Transactions> viewYearlyReport(Date StartDate,Date EndDate) throws UserException;
		public List<Transactions> viewDailyReport(Date StartDate) throws UserException;
		
		//public List<RequestTable> getAllRequest() throws UserException;
	
}
