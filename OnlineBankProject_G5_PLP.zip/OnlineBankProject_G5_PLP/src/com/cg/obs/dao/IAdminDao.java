package com.cg.obs.dao;

import java.util.List;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.exception.UserException;

public interface IAdminDao 
{
	public Customer getCustomerbyId(int id) throws UserException;
	public List<RequestTable> getAllRequest() throws UserException;
}
