package com.cg.obs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.exception.UserException;

@Repository("adminDao")
public class AdminDaoImpl implements IAdminDao
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public AdminDaoImpl()
	{
		
	}

	public AdminDaoImpl(EntityManager manager)
	{
	
		this.manager = manager;
	}

	public EntityManager getManager()
	{
		return manager;
	}


	public void setManager(EntityManager manager)
	{
		this.manager = manager;
	}

	@Override
	public Customer getCustomerbyId(int id) throws UserException
	{
		Customer customer=null ;
		try
		{
			customer = new Customer();
			customer  = manager.find(Customer.class,id);
			System.out.println("custId :"+customer);
		} 
		catch (Exception e)
		{
			throw new UserException("Customer ID not Found  " +e.getMessage());
		}
		if(customer == null)
		{
			throw new UserException("Customer Doesn't Exist With Id " +id);
		}
		return customer;
	}
	@Override
	public List<RequestTable> getAllRequest() throws UserException {
		List<RequestTable> request = null;
		try
		{
			TypedQuery<RequestTable> reqQuery = manager.createQuery("select r from RequestTable r",RequestTable.class);
			request = reqQuery.getResultList();
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		if(request==null || request.isEmpty())
		{
			throw new UserException("No Request Found");
		}
		return request;
	}
	

	

}
