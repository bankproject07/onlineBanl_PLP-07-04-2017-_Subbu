package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Account_Master")

public class AccountMaster {

	@Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="mygen")
//	@SequenceGenerator(name = "mygen",sequenceName="accid_seq")
	@Column(name="account_id")
	private long accountId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="customer_id")
	private int customerId;
	
	@Column(name="account_balance")
	private double accountBalance;
	
	@Column(name="open_date")
	private Date openDate;
	public AccountMaster(long accountId, String accountType, int customerId,
			double accountBalance, Date openDate) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.customerId = customerId;
		this.accountBalance = accountBalance;
		this.openDate = openDate;
	}
	
	public AccountMaster() {
		// TODO Auto-generated constructor stub
	}
	
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	@Override
	public String toString() {
		return "AccountMaster [accountId=" + accountId + ", accountType="
				+ accountType + ", customerId=" + customerId
				+ ", accountBalance=" + accountBalance + ", openDate="
				+ openDate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (accountId ^ (accountId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountMaster other = (AccountMaster) obj;
		if (accountId != other.accountId)
			return false;
		return true;
	}

	
	
	
}
