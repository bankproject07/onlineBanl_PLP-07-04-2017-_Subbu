package com.cg.obs.service;

import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public interface IUserService {

	public Users getUser(int id) throws UserException;
	public void registerUser(Users user) throws UserException;
	
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException;
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException;
	
	public int getCustomerId(Long accountno) throws UserException;
	public Customer getCustomer(int customerid) throws UserException;
	public void updateCustomerDetails(Customer customer) throws UserException;
	
	public int requestService(ServiceTracker services) throws UserException;
	public ServiceTracker getRequestedServiceList(int requestid) throws UserException;
	
	public int fundTransfer(FundTransfer transferInfo) throws UserException;
	public void insertTransaction(Transactions transaction) throws UserException;
	public void updateBalance(double Updatedbalance,Long accountNo) throws UserException;
	public void updatePayeeBalance(double Updatedbalance,Long accountNo) throws UserException;
	
	public void changePassword(Users user) throws UserException;
	public void updateLockStatus(int userid) throws UserException;
	
	public List<Payee> getPayee(long accountid) throws UserException;
	public void insertPayee(Payee payee) throws UserException;
	public boolean isPayeeAccountExists(long payeeAccountNo) throws UserException;
	
	public AccountMaster getAccount(long accountno);
	public int registerUser(Users user,Customer customer) throws UserException;
	
	public int addRequest(RequestTable resTab) throws UserException;
	public RequestTable getAccountId(int custId) throws UserException;
	public int isCheckBookRequestExist(Long accountno) throws UserException;
	
	//Admin
	public List<RequestTable> getAllRequest() throws UserException;
	public Customer getCustomerbyId(int id) throws UserException;
	
}
